//ReactDOM.render(1,2)
//ReactDOM.render(what you want to render, where you want to render);

import ReactDOM from "react-dom";
import App from "./App";
/* import "../node_modules/bootstrap/dist/css/bootstrap.css"; */
ReactDOM.render(<App />, document.getElementById("airtel_app"));
